from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Read resume and job description files
with open("resume.txt", "r", encoding="utf-8") as f:
    resume = f.read()

with open("job_description.txt", "r", encoding="utf-8") as f:
    job_desc = f.read()

documents = [resume, job_desc]

# Convert text to TF-IDF vectors
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(documents)

# Calculate similarity
similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])

score = similarity[0][0] * 100

print("Resume Match Score:", round(score,2), "%")