AI Resume Screening System (Simple ML Project)

Steps to run:

1. Install Python library
pip install -r requirements.txt

2. Run the project
python app.py

3. Output
The program will show the Resume Match Score between the resume and job description.